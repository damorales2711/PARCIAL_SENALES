clear all;                                                                  % elimine todas las variables que halla en el espacio de trabajo
clf;                                                                        % borre la figura que este en la ventana actual
clc;                                                                        % borra la ventana de comandos
Ts = 0.01;                                                                  % resolicion o tiempo de muestreo 
t = -10:Ts:10;                                                                % se�al de tiempo
                                                                            % se�al rampa evaluada entre [-5,5] con pendiente 3
                                                                            % (Corriemiento a la izquierda) con respecto al origen por 3
                                                                          % Se�al escalon unitario evaluada entre [-5,5], con un retardo de 3
a = ramp(t,2,0);
b = ramp(t,-4,-1);
c = ramp(t,2,-2);
y1= a + b + c;
subplot(3,2,1);
title('2tri(t-1)');
plot(t,y1,'k');axis([-1 5 -3 5]);
grid on;

d = ramp(t,2,-1);
e = ramp(t,-4,-2);
f = ramp(t,2,-3);
y2= d + e + f;
subplot(3,2,2);
title('tri((t-2)/2)');
plot(t,y2,'k'); axis([0 5 -3 5]); 
grid on;

g = impulse(t,3);
subplot(3,2,3);
title('delta(t+3)');
plot(t,g,'k'); axis([-4 0 -3 5]);
grid on;

h = 1 * ustep(t,-3);
subplot(3,2,4);
title('u(t-3)');
plot(t,h,'k'); axis([0 10 -3 5]);
grid on;

i = 0.333 * ramp(t,1,-5);
j = 0.333 * ramp(t,-2,-6);
m = 0.333 * ramp(t,1,-7);
l = i + j + m;
subplot(3,2,5);
title('ramp(3t-6)');
plot(t,l,'k'); axis([4 10 -3 5]);
grid on;
                                                                            % Definicion de las funciones rampa y escalon a continuacion.
function y = ramp(t,m,ad)
                                                                            % generacion de la se�al rampa 
                                                                            % t: tiempo evaluado
                                                                            % m: pendiente de la rampa
                                                                            % ad : retardo (negativo), avance (positivo)
                                                                            % Use: y = ramp(t,m,ad)
N= length(t);
y = zeros(1,N);
    for i = 1:N,
        if t(i)>= -ad,
            y(i) =m* (t(i)+ad);
        end
    end
end

function y = ustep(t,ad)
                                                                            % Generacion del escalon unitario
                                                                            % t: tiempo
                                                                            % ad : retardo (negativo), avance (positivo)
                                                                            % Use: y = ustep(t,ad)
N= length(t);
y = zeros(1,N);
    for i = 1:N,
        if t(i)>= -ad,
            y(i) = 1;
        end
    end
end

function y = impulse(t,ad)
                                                                            % Generacion del escalon unitario
                                                                            % t: tiempo
                                                                            % ad : retardo (negativo), avance (positivo)
                                                                            % Use: y = ustep(t,ad)
N= length(t);
y = zeros(1,N);
    for i = 1:N,
        if t(i)== -ad,
            y(i) = 1000;
        end
    end
end