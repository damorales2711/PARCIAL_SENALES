clear all;                                                                  % elimine todas las variables que halla en el espacio de trabajo
clf;                                                                        % borre la figura que este en la ventana actual
clc;                                                                        % borra la ventana de comandos
Ts = 0.01;                                                                  % resolicion o tiempo de muestreo 
t = -10:Ts:10;                                                                % se�al de tiempo
                                                                            % se�al rampa evaluada entre [-5,5] con pendiente 3
y1 = -2 * ustep(t,1);
y2 = ramp(t,2,1);
y3 = ramp(t,-2,-1);
y4 = 1 * ustep(t,-2);
y5 = ramp(t,-1,-2);
y6 = ramp(t,1,-4);
y7 = ramp(t,-1,-5);
y8 = ramp(t,1,-7);
y9 = 1 * ustep(t,-7);
y = y1 + y2 + y3 + y4 + y5 + y6 + y7 + y8 + y9;
plot(t,y,'k'); axis([-5 9 -3 7]); 
grid;
a=12;                                                                       % a: tama�o del texto en las etiqutas de las graficas
title('$V(t)=-2u(t+1)+2r(t+1)-2r(t-1)+u(t-2)-r(t-2)+r(t-4)-r(t-5)+u(t-7)$','interpreter','latex','FontSize',a)
xlabel('$t$','interpreter','latex','FontSize',a)
ylabel('$V(t)$','interpreter','latex','FontSize',a)
                                                                            % Definicion de las funciones rampa y escalon a continuacion.
function y = ramp(t,m,ad)
                                                                            % generacion de la se�al rampa 
                                                                            % t: tiempo evaluado
                                                                            % m: pendiente de la rampa
                                                                            % ad : retardo (negativo), avance (positivo)
                                                                            % Use: y = ramp(t,m,ad)
N= length(t);
y = zeros(1,N);
    for i = 1:N,
        if t(i)>= -ad,
            y(i) =m* (t(i)+ad);
        end
    end
end

function y = ustep(t,ad)
                                                                            % Generacion del escalon unitario
                                                                            % t: tiempo
                                                                            % ad : retardo (negativo), avance (positivo)
                                                                            % Use: y = ustep(t,ad)
N= length(t);
y = zeros(1,N);
    for i = 1:N,
        if t(i)>= -ad,
            y(i) = 1;
        end
    end
end

function y = impulse(t,ad)
                                                                            % Generacion del escalon unitario
                                                                            % t: tiempo
                                                                            % ad : retardo (negativo), avance (positivo)
                                                                            % Use: y = ustep(t,ad)
N= length(t);
y = zeros(1,N);
    for i = 1:N,
        if t(i)== -ad,
            y(i) = 1000;
        end
    end
end