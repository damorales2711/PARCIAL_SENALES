clear all;                                                                  % elimine todas las variables que halla en el espacio de trabajo
clf;                                                                        % borre la figura que este en la ventana actual
clc;                                                                        % borra la ventana de comandos
Ts = 0.01;                                                                  % resolicion o tiempo de muestreo 
t = -5:Ts:10;                                                                % se�al de tiempo
                                                                            % se�al rampa evaluada entre [-5,5] con pendiente 3
                                                                            % (Corriemiento a la izquierda) con respecto al origen por 3
                                                                           % Se�al escalon unitario evaluada entre [-5,5], con un retardo de 3
y1 = 3 * ustep(-t,3);
y = y1;
plot(t,y,'k'); axis([-3 15 -3 15]); 
grid;
a=12;                                                                       % a: tama�o del texto en las etiqutas de las graficas
title('$3u(3-t)$','interpreter','latex','FontSize',a)
xlabel('$t$','interpreter','latex','FontSize',a)
ylabel('$Escalon$','interpreter','latex','FontSize',a)
                                                                            % Definicion de las funciones rampa y escalon a continuacion.
function y = ramp(t,m,ad)
                                                                            % generacion de la se�al rampa 
                                                                            % t: tiempo evaluado
                                                                            % m: pendiente de la rampa
                                                                            % ad : retardo (negativo), avance (positivo)
                                                                            % Use: y = ramp(t,m,ad)
N= length(t);
y = zeros(1,N);
    for i = 1:N,
        if t(i)>= -ad,
            y(i) =m* (t(i)+ad);
        end
    end
end

function y = ustep(t,ad)
                                                                            % Generacion del escalon unitario
                                                                            % t: tiempo
                                                                            % ad : retardo (negativo), avance (positivo)
                                                                            % Use: y = ustep(t,ad)
N= length(t);
y = zeros(1,N);
    for i = 1:N,
        if t(i)>= -ad,
            y(i) = 1;
        end
    end
end

function y = impulse(t,ad)
                                                                            % Generacion del escalon unitario
                                                                            % t: tiempo
                                                                            % ad : retardo (negativo), avance (positivo)
                                                                            % Use: y = ustep(t,ad)
N= length(t);
y = zeros(1,N);
    for i = 1:N,
        if t(i)== -ad,
            y(i) = 1000;
        end
    end
end